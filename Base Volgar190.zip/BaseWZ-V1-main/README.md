# BaseWZ-V1 par WayZe#0001

# ⚠️ Téléchargement de la base ⚠️

 - ➡️ [Lien de téléchargement de la base](https://mega.nz/folder/B8ISzZST#O-R-mnyGG8MpA9gZDzxOYw)⬅️

# ↓

Bonjour à tous je vous présente aujourd'hui cette Base FiveM qui tourne en Double Job sur la première version de l'es_extended réalisé EXCLUSIVEMENT en live sur la [chaîne Youtube de WayZe](https://youtube.com/WayZe) +24 heures de streams et 0 minute de développement hors stream !

Je vous prie de ne pas vous attribuer cette base et de la vendre, toute personne qui s'appropriera ma base assumera les conséquences 🙂

# Preview

Vidéo de présentation de la base :
 - 🎥 [Base Preview](https://youtu.be/j-H1p0sB4yM)  

Vidéo Tutoriel d'Installation de la base en Local Host :
 - 🎥 [Installation de la base en Local Host](https://youtu.be/GF0XyMR2woE)

Vidéo Tutoriel d'Installation de la base sur Hébergeur :
 - 🎥 [Installation de la base sur un Hébergeur](https://youtu.be/_pvsFfvgcNI)
 
# Installation FR 

Tutoriel écrit disponible demain dans la journée.

- Si vous avez besoin d'aide pour l'installation : https://discord.gg/eX9GXWN 🌐

# Documentation FR 

- [Documentation FR](https://github.com/WayZeTV/BaseWZ-V1/blob/main/documentation.md)

# Author 
Discord : WayZe#0001 | Youtube : WayZe | Twitter : @WayZeTV

### License
Base Serveur - Base FiveM réalisé sur la V1 de ESX

Copyright (C) 2021 WayZe

This program Is free software: you can redistribute it And/Or modify it under the terms Of the GNU General Public License As published by the Free Software Foundation, either version 3 Of the License, Or (at your option) any later version.

This program Is distributed In the hope that it will be useful, but WITHOUT ANY WARRANTY without even the implied warranty Of MERCHANTABILITY Or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License For more details.

You should have received a copy Of the GNU General Public License along with this program. If Not, see http://www.gnu.org/licenses/.

 
