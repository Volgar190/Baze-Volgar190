# Documentation FR

### Changer l'argent de départ (essentialmode)
Pour changer l'argent de départ, veuillez suivre ce chemin d'accès :
`resources/[scripts]/[essential]/essentialmode/server/util.lua`
Vous pouvez ensuite changer l'argent de départ en Cash (`Ligne 11`) et l'argent de départ en Banque (`Ligne 12`)

### Changer le texte et les images dans le menu création personnage (esx_identity)
Pour changer le texte et les images dans le menu de création du personnage, veuillez suivre ce chemin d'accès : `resources/[scripts]/[esx]/esx_identity/html/index.html`
Vous pouvez ensuite changer l'image à la `Ligne 21` entre y mettant le lien : `src="lien image"` puis changer le texte aux `Lignes 59` et `61`

### Changer le point d'apparition lors de la première connexion au serveur 
Pour changer le point d'apparition lors de la première connexion au serveur, veuillez suive de chemin d'accès :
`resources/[base]/[maps]/fivem-map-skater/map.lua` et `resources/[base]/[maps]/Free-Access/map.lua` et il suffit de changer les coordonées par celle que vous souhaitez mettre
